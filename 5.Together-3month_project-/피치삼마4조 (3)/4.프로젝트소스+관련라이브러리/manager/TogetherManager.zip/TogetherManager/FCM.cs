﻿using FirebaseAdmin;
using FirebaseAdmin.Messaging;
using Google.Apis.Auth.OAuth2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TogetherManager
{
    class FCM
    {

        public FCM()
        {
            FirebaseApp.Create(new AppOptions()
            {
                Credential = GoogleCredential.FromFile("D:\\FcmKey\\together-c49b9-firebase-adminsdk-pomji-9936711e8c.json")
            });
        }

        public async void FcmCreate(string token, string id)
        {

            var dvice_token = token;

            var message = new Message()
            {
                Data = new Dictionary<string, string>()
                {
                    {"title",id + "회원님" },
                    {"body","승인되었습니다." },

                },
                Token = dvice_token,
            };

            string response = await FirebaseMessaging.DefaultInstance.SendAsync(message);
           
        }
    }
}
