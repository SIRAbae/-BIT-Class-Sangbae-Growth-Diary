﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql;
using MySql.Data.MySqlClient;

namespace TogetherManager
{
    class DBcon
    {
        // private string _connectionString = "SERVER=서버;DATABASE=데이타베이스명;UID=아이디;PASSWORD=패스워드;";
        private string id;
        private string pw;
        MySqlConnection conn;

        List<User_info> u_list = new List<User_info>();

        public Boolean DBconnect(string id, string pw)
        {
            this.id = id;
            this.pw = pw;
            string mysql_conn_str = "Server=127.0.0.1;Database=test1;Uid=" + id + ";Pwd=" + pw;
             conn = new MySqlConnection(mysql_conn_str);
            MySqlCommand cmd = conn.CreateCommand();
           
            try
            {
                conn.Open();
                //MessageBox.Show("연결성공");
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;

            }

        }

        public void ApproveMember(string id)
        {
            string insert = "update user set U_MEMBER = 1 where U_ID=" + "\"" + id + "\";";
            MySqlCommand cmd = new MySqlCommand(insert, conn);
            cmd.ExecuteNonQuery();
        }

        public List<User_info> getAll_userInfo()
        {
            try
            {
                string sql = "select * from user;";

                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader reader = cmd.ExecuteReader();
                while(reader.Read())
                {
                    int no =        (int)reader["user_no"];
                    string name =   (string)reader["U_NAME"];
                    string birth =  (string)reader["U_BIRTH"];
                    string gender = (string)reader["U_GENDER"];
                    string phone =  (string)reader["U_PHONE"];
                    string id =     (string)reader["U_ID"];
                    string pw =     (string)reader["U_PW"];
                    string nick =   (string)reader["U_NICK"];
                    string region = (string)reader["U_REGION"];
                    string walktime = (string)reader["U_WALKTIME"];
                    string date =   (string)reader["U_DATE"];
                    string intro =  (string)reader["U_INTRO"];
                    double lat =     double.Parse((string)reader["U_LAT"], CultureInfo.InvariantCulture) ;
                    double lon =     double.Parse((string)reader["U_LONG"], CultureInfo.InvariantCulture);
                    int member =    (int)reader["U_MEMBER"];
                    string token =  (string)reader["U_TOKEN"];

                    string res = no + name + birth + gender + id + pw + nick + region + walktime + date + intro + lat + lon + member + token;

                    User_info u_info = new User_info(no,name,birth,gender,phone,id,pw,nick,region,walktime,date,intro,lat,lon,member,token);

                    

                    u_list.Add(u_info);
                    

                    //MessageBox.Show(res);
                    //MessageBox.Show(u_list.Count.ToString());
                    //MessageBox.Show(u_list[0].U_ID);
                }
                reader.Close();
                return u_list;


            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return null;
            }
        }

        public List<User_info> Unapproved_User()
        {
            try
            {
                string sql = "select * from user where U_MEMBER = 0;";

                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {

                    int no = (int)reader["user_no"];
                    string name = (string)reader["U_NAME"];
                    string birth = (string)reader["U_BIRTH"];
                    string gender = (string)reader["U_GENDER"];
                    string phone = (string)reader["U_PHONE"];
                    string id = (string)reader["U_ID"];
                    string pw = (string)reader["U_PW"];
                    string nick = (string)reader["U_NICK"];
                    string region = (string)reader["U_REGION"];
                    string walktime = (string)reader["U_WALKTIME"];
                    string date = (string)reader["U_DATE"];
                    string intro = (string)reader["U_INTRO"];
                    double lat = double.Parse((string)reader["U_LAT"], CultureInfo.InvariantCulture);
                    double lon = double.Parse((string)reader["U_LONG"], CultureInfo.InvariantCulture);
                    int member = (int)reader["U_MEMBER"];
                    string token = (string)reader["U_TOKEN"];

                    string res = no + name + birth + gender + id + pw + nick + region + walktime + date + intro + lat + lon + member + token;

                    User_info u_info = new User_info(no, name, birth, gender, phone, id, pw, nick, region, walktime, date, intro, lat, lon, member, token);



                    u_list.Add(u_info);

                }
                reader.Close();
                return u_list;


            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
                return null;
            }
        }

    }
}
