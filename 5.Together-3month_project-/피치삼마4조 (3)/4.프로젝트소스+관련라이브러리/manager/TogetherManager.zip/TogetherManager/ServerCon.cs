﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace TogetherManager
{
    public class ServerCon
    {
        private const string IP = "172.18.206.232";

        private intConverter ic = null;

        private Socket socket = null;
        private Thread recv_thread = null;

        private bool isSokcet = false;

        public Form1 form1;

        public ServerCon(Socket sock,Form1 f)
        {
            form1 = f;
            this.socket = sock;
            ic = new intConverter();
        }
        public Boolean Connect()
        {
            try
            {
                if (socket == null)
                {

                    socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
                    socket.Connect(IPAddress.Parse(IP), 9000);

                    if (socket.Connected == true)
                    {
                        isSokcet = true;
                        recv_thread = new Thread(new ThreadStart(Recv_thread));     //쓰레드 설정
                        recv_thread.Start();
                        return true;
                    }

                }
                else if (socket != null)
                {
                    return false;
                }

                return false;

            } catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        public Boolean Disconnect()
        {
            try
            {
                if (socket.Connected == true)
                {
                    isSokcet = false;
                    socket.Disconnect(false);
                    socket.Close();

                    return false;
                }
                else
                    return false;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        public bool Send(string msg,int type)
        {
            
            byte[] Type = new byte[4];
            Type = ic.intToByteArray(type);
                //BitConverter.GetBytes(type);
            socket.Send(Type);

            
            byte[] data = Encoding.Default.GetBytes(msg);
            int size = data.Length;

            byte[] data_size = new byte[4];
            data_size = ic.intToByteArray(size);
            socket.Send(data_size);
            socket.Send(data, 0, size, SocketFlags.None);

            
            return true;
        }

        public byte[] ReceiveData(Socket sock)     //클라이언트 소켓으로부터 데이터를 얻어냄
        {
            try
            {
                int total = 0;
                int size = 0;
                int left_data = 0;
                int recv_data = 0;

                // 1) 수신할 데이터 크기 알아내기 
                byte[] data_size = new byte[4];
                recv_data = sock.Receive(data_size, 0, 4, SocketFlags.None);        //소켓으로부터 매니저한테 오는 값인지 확인 = 4
                size = ic.ByteToInt(data_size);
                //================================================
                if (size == 4)
                {
                    // 2) 수신할 데이터 크기 알아내기 
                    byte[] data_size1 = new byte[4];
                    recv_data = sock.Receive(data_size1, 0, 4, SocketFlags.None);        //소켓으로부터 전송데이타 크기 받기
                    size = ic.ByteToInt(data_size1);



                    left_data = size;       //전송받아야할 실제 바이트크기
                    byte[] data = new byte[size];

                    // 실제 데이터 수신
                    while (total < size)
                    {
                        recv_data = sock.Receive(data, total, left_data, 0);            //소켓으로부터 실제 데이터를 전송받음
                        if (recv_data == 0) break;
                        total += recv_data;
                        left_data -= recv_data;
                    }
                    //한번에 전송되는게 아니라 '총 받아야할 크기' - '받고있는 크기' 를 반복함

                    return data;//이게 받은 데이터이다.
                } else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }

        public void Recv_thread()
        {
            byte[] getStr = null;
            try
            {
                while (isSokcet == true)
                {
                    getStr = ReceiveData(socket);



                    string str = Encoding.Default.GetString(getStr);
                    //str = Regex.Replace(str, @"['x5C""]", (string)s, RegexOptions.Singleline);
                    //str = Regex.Replace(str, @"[!]", , RegexOptions.Singleline);
                    form1.ParserByCode(str);

                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

    }

    
}


    //출처: https://nowonbun.tistory.com/167 [명월 일지]

    

