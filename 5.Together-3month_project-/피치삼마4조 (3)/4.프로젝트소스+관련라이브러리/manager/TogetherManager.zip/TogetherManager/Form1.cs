﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace TogetherManager
{
    public partial class Form1 : Form
    {
        DBcon db = null;
        ServerCon serverCon = null;
        Socket socket = null;
        List<User_info> user_list = null;
        FCM fcm = null;
        JSON js = null;

        private bool serverStatus = false;

        enum DataPacketType { MANAGER = 1, IMAGE = 2, DATA = 3, Disconnect = 4 };
        public Form1()
        {
            InitializeComponent();
            //defaultButton();
            user_list = new List<User_info>();
            fcm = new FCM();
            js = new JSON();


        }

        //서버연결
        private void button1_Click_1(object sender, EventArgs e)
        {
            if (serverCon == null && serverStatus == false)
            {
                serverCon = new ServerCon(socket, this);
                bool iscon = serverCon.Connect();
                serverStatus = iscon;
                MessageBox.Show("Connected.");
            }
            else
                MessageBox.Show("이미 서버에 연결되었습니다.");

        }
        //서버연결해제
        private void button5_Click(object sender, EventArgs e)
        {
            if (serverCon != null && serverStatus == true)
            {
                serverCon.Send("로그아웃", (int)DataPacketType.Disconnect);
                bool disCon = serverCon.Disconnect();
                serverStatus = disCon;
                serverCon = null;
                MessageBox.Show("Disconnected");
            }
            else
                MessageBox.Show("서버에 연결되있지 않습니다.");
        }

        //회원정보 불러오기
        private void button2_Click(object sender, EventArgs e)
        {
            user_list.Clear();

            if (serverCon != null)
            {
                string getAll = js.getAllUser();
                serverCon.Send(getAll, (int)DataPacketType.MANAGER);

            }
            else
            {
                MessageBox.Show("서버에 연결되어있지 않습니다.");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            listView1.View = View.Details;           //컬럼형식으로 변경

            listView1.FullRowSelect = true;          //Row 전체 선택

            listView1.Columns.Add("User_no", 120);        //컬럼추가
            listView1.Columns.Add("Name", 100);
            listView1.Columns.Add("Birth", 100);
            listView1.Columns.Add("Gender", 170);
            listView1.Columns.Add("Phone", 120);        //컬럼추가
            listView1.Columns.Add("ID", 100);
            listView1.Columns.Add("PW", 100);
            listView1.Columns.Add("Nick", 170);
            listView1.Columns.Add("Region", 120);        //컬럼추가
            listView1.Columns.Add("WalkTime", 100);
            listView1.Columns.Add("Date", 100);
            listView1.Columns.Add("Intro", 170);
            listView1.Columns.Add("Lat", 120);        //컬럼추가
            listView1.Columns.Add("Long", 100);
            listView1.Columns.Add("Member", 100);
            listView1.Columns.Add("Token", 170);
        }

        //리스트뷰에 데이터 넣기
        private void DataBind()
        {
            listView1.BeginUpdate();

            for (int i = 0; i < user_list.Count(); i++)
            {

                ListViewItem listView = new ListViewItem(user_list[i].user_no.ToString());
                listView.SubItems.Add(user_list[i].U_NAME.ToString());
                listView.SubItems.Add(user_list[i].U_BIRTH.ToString());
                listView.SubItems.Add(user_list[i].U_GENDER.ToString());
                listView.SubItems.Add(user_list[i].U_PHONE.ToString());
                listView.SubItems.Add(user_list[i].U_ID.ToString());
                listView.SubItems.Add(user_list[i].U_PW.ToString());
                listView.SubItems.Add(user_list[i].U_NICK.ToString());
                listView.SubItems.Add(user_list[i].U_REGION.ToString());
                listView.SubItems.Add(user_list[i].U_WALKTIME.ToString());
                listView.SubItems.Add(user_list[i].U_DATE.ToString());
                listView.SubItems.Add(user_list[i].U_INTRO.ToString());
                listView.SubItems.Add(user_list[i].U_LAT.ToString());
                listView.SubItems.Add(user_list[i].U_LONG.ToString());
                listView.SubItems.Add(user_list[i].U_MEMBER.ToString());
                listView.SubItems.Add(user_list[i].U_TOKEN.ToString());

                listView1.Items.Add(listView);

            }
            listView1.EndUpdate();

        }
        private void unRegiDataBind(List<User_info> u_list)
        {
            listView1.BeginUpdate();

            for (int i = 0; i < u_list.Count(); i++)
            {

                ListViewItem listView = new ListViewItem(user_list[i].user_no.ToString());
                listView.SubItems.Add(u_list[i].U_NAME.ToString());
                listView.SubItems.Add(u_list[i].U_BIRTH.ToString());
                listView.SubItems.Add(u_list[i].U_GENDER.ToString());
                listView.SubItems.Add(u_list[i].U_PHONE.ToString());
                listView.SubItems.Add(u_list[i].U_ID.ToString());
                listView.SubItems.Add(u_list[i].U_PW.ToString());
                listView.SubItems.Add(u_list[i].U_NICK.ToString());
                listView.SubItems.Add(u_list[i].U_REGION.ToString());
                listView.SubItems.Add(u_list[i].U_WALKTIME.ToString());
                listView.SubItems.Add(u_list[i].U_DATE.ToString());
                listView.SubItems.Add(u_list[i].U_INTRO.ToString());
                listView.SubItems.Add(u_list[i].U_LAT.ToString());
                listView.SubItems.Add(u_list[i].U_LONG.ToString());
                listView.SubItems.Add(u_list[i].U_MEMBER.ToString());
                listView.SubItems.Add(u_list[i].U_TOKEN.ToString());

                listView1.Items.Add(listView);

            }
            listView1.EndUpdate();

        }
        //로그인 후에 버튼활성화
        private void buttonControl(bool i)
        {
            if (i == true)
            {
                button2.Enabled = true;
                button3.Enabled = true;
                button4.Enabled = true;

            }
        }

        private void defaultButton()
        {
            button2.Enabled = false;
            button3.Enabled = false;
            button4.Enabled = false;

        }

        private void listView1_DoubleClick(object sender, EventArgs e)
        {
            textBox3.Text = listView1.FocusedItem.SubItems[1].Text;
            textBox4.Text = listView1.FocusedItem.SubItems[2].Text;
            textBox5.Text = listView1.FocusedItem.SubItems[3].Text;
            textBox15.Text = listView1.FocusedItem.SubItems[4].Text;
            textBox6.Text = listView1.FocusedItem.SubItems[5].Text;
            textBox8.Text = listView1.FocusedItem.SubItems[6].Text;
            textBox7.Text = listView1.FocusedItem.SubItems[7].Text;
            textBox16.Text = listView1.FocusedItem.SubItems[8].Text;
            textBox17.Text = listView1.FocusedItem.SubItems[9].Text;
            textBox9.Text = listView1.FocusedItem.SubItems[10].Text;
            textBox10.Text = listView1.FocusedItem.SubItems[11].Text;
            textBox11.Text = listView1.FocusedItem.SubItems[12].Text;
            textBox12.Text = listView1.FocusedItem.SubItems[13].Text;
            textBox13.Text = listView1.FocusedItem.SubItems[14].Text;
            textBox14.Text = listView1.FocusedItem.SubItems[15].Text;

            string id = listView1.FocusedItem.SubItems[5].Text;

            string filePath1 = "D:\\AndroidStudio-Study-Github\\Together\\Together_Test\\Picture\\" + id + "\\SignUp-" + id + "-0.bmp";
            string filePath2 = "D:\\AndroidStudio-Study-Github\\Together\\Together_Test\\Picture\\" + id + "\\SignUp-" + id + "-1.bmp";

            pictureBox1.Image = Image.FromFile(filePath1);
            pictureBox2.Image = Image.FromFile(filePath2);


        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void textBox16_TextChanged(object sender, EventArgs e)
        {

        }

        //정규회원으로 승인하기
        private void button3_Click(object sender, EventArgs e)
        {
            string user_no = textBox6.Text.ToString();
            string token = textBox14.Text.ToString();

            string res = js.FCMSend(token, user_no);
            serverCon.Send(res, (int)DataPacketType.MANAGER);
            /*
            string id = textBox6.Text;
            if (textBox13.Text == "0")
            {
                
                db.ApproveMember(id);
                fcm.FcmCreate(textBox14.Text, id);

                listView1.Items.Clear();
                user_list = db.getAll_userInfo();
                if (user_list == null)
                {
                    MessageBox.Show("불러온값없음");
                }
                else
                {
                    DataBind();
                    user_list.Clear();
                    clear_INFO();
                }

                MessageBox.Show(id + "승인성공했습니다.");

            }
            else
            {
                MessageBox.Show(id + "님은 이미 승인되었습니다.");

            }
            */

        }


        //승인되지않은 회원 목록 불러오기
        private void button4_Click(object sender, EventArgs e)
        {

            List<User_info> unRegi = new List<User_info>();
            for(int i = 0; i < user_list.Count; i++)
            {
                if(user_list[i].U_MEMBER == 0)
                {
                    unRegi.Add(user_list[i]);
                }
            }
            
            listView1.Items.Clear();
            

            if (unRegi == null)
            {
                MessageBox.Show("불러온값없음");
            }
            else
            {
                unRegiDataBind(unRegi);
                clear_INFO();
            }
            
        }

        //승인하고 인포값 지우기
        private void clear_INFO()
        {
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox15.Clear();
            textBox6.Clear();
            textBox8.Clear();
            textBox7.Clear();
            textBox16.Clear();
            textBox17.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();

            pictureBox1.Image = null;
            pictureBox2.Image = null;
            pictureBox3.Image = null;
            pictureBox4.Image = null;
        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            try
            {
                if (serverCon != null && serverStatus == true)
                {
                    serverCon.Send("연결해제", (int)DataPacketType.Disconnect);
                    bool disCon = serverCon.Disconnect();
                    serverStatus = disCon;
                    serverCon = null;
                    MessageBox.Show("Disconnected");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        public void ParserByCode(string str)
        {

            string[] tokens = str.Split('@');
            string token = tokens[0];
            switch (token)
            {
                case "GETALLUSER": getAlluser(str); break;
                case "APPROVED": getApproveRes(str); break;
                case "DENIED": getApproveRes(str); break;


            }

        }

        public void getAlluser(string str)
        {
            string[] tokens = str.Split('@');
            string[] tokens1 = tokens[1].Split('!');
            for (int i = 1; i < tokens1.Length; i++)
            {
                string[] res = tokens1[i].Split('/');


                User_info user_Info = new User_info(int.Parse(res[0]), res[1], res[2], res[3], res[4], res[5], res[6], res[7], res[8],
                    res[9], res[10], res[11], double.Parse(res[12]), double.Parse(res[13]), int.Parse(res[14]), res[15]);

                user_list.Add(user_Info);
                

                


            }

            this.Invoke(new MethodInvoker(                  //크로스스레드 해결
                    delegate ()
                    {
                        listView1.Items.Clear();
                        if (user_list == null)
                        {
                            MessageBox.Show("불러온값없음");
                        }
                        else
                        {
                            DataBind();
                            clear_INFO();
                        }
                    }
                )
            );
        }

        public void getApproveRes(string str)
        {
            string[] tokens = str.Split('@');
            if(tokens[0].Equals("APPROVED"))
            {
                        this.Invoke(new MethodInvoker(                  //크로스스레드 해결
                                delegate ()
                                {
                                    MessageBox.Show(tokens[1]);
                                }
                            )
                        );
            } else if(tokens[0].Equals("DENIED"))
            {
                        this.Invoke(new MethodInvoker(                  //크로스스레드 해결
                                delegate ()
                                {
                                    MessageBox.Show(tokens[1]);
                                }
                            )
                        );
            }

            
        }


    }
}
