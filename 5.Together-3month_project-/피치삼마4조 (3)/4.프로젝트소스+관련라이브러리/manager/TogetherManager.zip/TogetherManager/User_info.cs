﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TogetherManager
{
    class User_info
    {
        public int user_no;
        public string U_NAME;
        public string U_BIRTH;
        public string U_GENDER;
        public string U_PHONE;
        public string U_ID;
        public string U_PW;
        public string U_NICK;
        public string U_REGION;
        public string U_WALKTIME;
        public string U_DATE;
        public string U_INTRO;
        public double U_LAT;
        public double U_LONG;
        public int U_MEMBER;
        public string U_TOKEN;

        public User_info(int u_no, string name, string birth, string gender, string phone, string id, string pw, string nick,
            string region, string walktime, string date, string intro, double lat, double lon, int member, string token)
        {

            user_no = u_no;
            U_NAME = name;
            U_BIRTH = birth;
            U_GENDER = gender;
            U_PHONE = phone;
            U_ID = id;
            U_PW = pw;
            U_NICK = nick;
            U_REGION = region;
            U_WALKTIME = walktime;
            U_DATE = date;
            U_INTRO = intro;
            U_LAT = lat;
            U_LONG = lon;
            U_MEMBER = member;
            U_TOKEN = token;

        }
    }

    
}
