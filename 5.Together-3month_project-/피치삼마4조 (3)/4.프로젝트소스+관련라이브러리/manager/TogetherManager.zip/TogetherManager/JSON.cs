﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TogetherManager
{
    class JSON
    {
        class Code
        {
            public String Data { get; set; }
        }

        public string getAllUser() {
            JObject jo = new JObject();

            jo.Add("CODE", "GetAll");

            return jo.ToString();

        }

        public string FCMSend(string token,string id)
        {
            JObject Fcm = new JObject();

            Fcm.Add("ID", id);
            Fcm.Add("Token", token);

            JObject jo = new JObject();
            jo.Add("CODE", "Approve");
            jo.Add("Content", Fcm);


            return jo.ToString();

        }

    }
}
