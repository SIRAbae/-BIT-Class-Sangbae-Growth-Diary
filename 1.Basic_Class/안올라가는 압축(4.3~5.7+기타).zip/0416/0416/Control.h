//Control.h

#pragma once
#include "wbarray.h"

class Control
{
private:
	wbarray* stulist;

public:
	Control(int max);
	~Control();
public:
	void InsertStudent();
	void PrintAllStudent();
	void SellectStudent();
	void UpdateStudent();
	void delectStUdent();
	
private:
	int nametoidx(string name);
};

