#include "account.h"



account::account(string _n, int _a, int _b, string _d)
{
	name = _n;
	accid = _a;
	balance = _b;
	date = _d;

}

account::account(string _n, int _a)
{
	name = _n;
	accid = _a;
	balance = 0;
	date="2019.04.17"

}


account::~account()
{
}


bool account::inputmoney(int money)
{
	if (money <= 0)
		return false;
	balance += money;
	return true;
}


bool account::outputmoney(int money)
{
	return false;
}


void account::printline()
{
	cout << name.c_str() << "\t";
	cout << accid << "\t";
	cout << balance << "\t";
	cout << date.c_str << "\t";
}


void account::print()
{
	cout << "�̸� : " << name_c.str() << "\t";
	cout << "���¹�ȣ : "<< 
}



string account::getname()
{
	return name;
}


int account::getaccid()
{
	return accid;
}


int account::getbalance()
{
	return balance;
}


string account::getdate()
{
	return date;
}
