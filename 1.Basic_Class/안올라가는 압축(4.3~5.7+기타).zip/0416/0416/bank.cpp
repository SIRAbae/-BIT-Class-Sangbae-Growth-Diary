#include "bank.h"



bank::bank()
{
}


bank::~bank()
{
}


void bank::makeaccount()
{
}


void bank::printallaccount()
{
}


void bank::selectaccount()
{
}
void bank::print()
{
}


int bank::nametoidx(string name)
{
	return 0;
}
