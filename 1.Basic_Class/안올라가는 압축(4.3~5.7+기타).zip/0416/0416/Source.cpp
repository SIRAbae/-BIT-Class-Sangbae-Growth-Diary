//Source.cpp
#include<iostream>
using namespace std;

#include "Control.h"

int main()
{
	Control con(10);
	con.InsertStudent();
	con.InsertStudent();
	con.SellectStudent();
	con.PrintAllStudent();
	//=================================
	con.UpdateStudent();
	con.PrintAllStudent();
	//=================================
	con.delectStUdent();
	con.PrintAllStudent();
	return 0;

}