#pragma once

#include<iostream>
using namespace std;
#pragma once

class bank
{
public:
	bank();
	~bank();
	


public:
	void makeaccount();
	void printallaccount();
	void selectaccount();
	void print();
private:
	int nametoidx(string name);
};

