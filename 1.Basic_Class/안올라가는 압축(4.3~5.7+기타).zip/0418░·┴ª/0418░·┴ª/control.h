//control.h

#include <iostream>
using namespace std;
#pragma once

class control
{
private:
	string title;	//����
	string name;    //����
	int page;	//������
	int cost;	//����
	string date;

public:
	control(string _t, string _n, int _p, int _c);
	~control();
	
public:
	string gettitle();
	string getname();
	int getpage();
	int getcost();
	bool money(int _j);

public:
	void printline();
	void print();
};

