//bkarray.h

#pragma once
class bkarray
{
private:
	void* base[10];
	int capacity;
	int size;

public:
	bkarray();
	~bkarray();

public:
	int getcapacity();
	int getsize();
	void* getdata(int idx);
	
public:
	void push_back(void* value);
	void erase(int idx);
};

