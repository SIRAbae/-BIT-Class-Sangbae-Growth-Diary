//book.h
#include <iostream>
using namespace std;
#pragma once

#include "bkarray.h"

class book
{
private:
	bkarray* acclist;

public:
	book();
	~book();

public:
	void makecontrol();
	void printallcontrol();
	void selectcontrol();
	void selectcontrolname();
	void changtitleebook();
	void changnameebook();
	void deletecontrol();
private:
	int nametoidx(string name);
	int titletoidx(string title);
};

