//app.cpp
#pragma once

class book;

class app
{
private:
	book* book1;
public:
	app();
	~app();

public:
	void init();
	void run();
	void exit();

public:
	void logo();
	void ending();
	void menuprint();
};

