//control.cpp

#include "control.h"



control::control(string _t, string _n, int _p, int _c)
{
	title = _t;
	name = _n;
	page = _p;
	cost = _c;

}


control::~control()
{
}


string control::gettitle()
{
	return title;
}


string control::getname()
{
	return name;
}


int control::getpage()
{
	return page;
}


int control::getcost()
{
	return cost;
}

bool control::money(int _j)
{
	cost = _j;
	if (_j < 0)
	{
		return false;
	}
	return true;
}

void control::printline()
{
	cout << title.c_str() << "\t";
	cout << name.c_str() << "\t";
	cout << page << "��\t";
	cout << cost << "��\t" << endl;
}


void control::print()
{
	cout << "��    �� : " << title.c_str() << "\t";
	cout << "��    �� : " << name.c_str() << "\t";
	cout << "������ �� : " << page << "��\t";
	cout << "��    ��" << cost << "��\t" << endl;
}
