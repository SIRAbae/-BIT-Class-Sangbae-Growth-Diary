//bank.cpp
#include<iostream>
using namespace std;

#include "account.h"
#include "wbarray.h"
#include "bank.h"




bank::bank()
{
	acclist = new wbarray;
}


bank::~bank()
{
	delete acclist;
}


void bank::makeaccount() //insert
{
	int accid, balance;
	string name[20], date[20];
	cout << "��  �� : "; cin >> name;
	cout << "���¹�ȣ : "; cin >> accid;
	cout << "�� �� �� : "; cin >> balance;
	cout << "�� �� ��: "; cin >> date;

	account *acc = new account(name, accid, balance, date);
	acclist->push_back(acc);

		cout<< "����Ǿ����ϴ�."<<
}


void bank::printallaccount()
{
}


void bank::selectaccount()
{
	try
	{
		char name[20];
		cout << "�˻��� �̸� : "; cin >> name;
	}
}

int bank::nametoidx(string name)
{
	return 0;
}


void bank::addmoney()
{
}


void bank::minmoey()
{
}


void bank::deletemony()
{
}
