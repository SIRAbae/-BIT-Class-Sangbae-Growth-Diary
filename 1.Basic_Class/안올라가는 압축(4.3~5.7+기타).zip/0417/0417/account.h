//account.h

#include<iostream>
using namespace std;
#pragma once


class account
{
private:
	string name;
	int accid;
	int balance;
	string date;

public:
	account(string _n, int _a, int _b, string _d);
	account(string _n, int _a);
	~account();

public:
	bool inputmoney(int money);
	bool outputmoney(int money);
	void printline();
	void print();

public:
	string getname();
	int getaccid();
	int getbalance();
	string getdate();
};