
#include<iostream>
#include "bank.h"
using namespace std; 
#pragma once
class app
{
private:
	bank* bank1;

public:
	app();
	~app();

public:
	void init();
	void run();
	void exit();
	void logo();
	void ending();
	void menuprint();
};

