//std.h
#pragma once
#include "control.h"
#include "account.h"
#include "app.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>	//system
#include <conio.h>		//_getch
