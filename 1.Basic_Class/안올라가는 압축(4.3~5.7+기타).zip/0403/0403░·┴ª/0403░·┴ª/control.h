//control.h
#pragma once

void control_selectall();
void control_newaccount();
void control_deposit();
void control_search();
void control_correct();
void control_withdraw();
void control_delete();
int keytoidx(const char* key);
