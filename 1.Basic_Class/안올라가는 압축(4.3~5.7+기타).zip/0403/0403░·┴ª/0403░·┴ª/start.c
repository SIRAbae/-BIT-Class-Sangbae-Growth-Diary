//start.c
#include "std.h"

void main()
{
	app_init();
	app_run();
	app_exit();
}