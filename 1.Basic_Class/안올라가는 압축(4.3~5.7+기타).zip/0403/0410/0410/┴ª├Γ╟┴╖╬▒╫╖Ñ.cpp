//�������α׷�.cpp
#include<iostream>
#include<conio.h>
using namespace std;

struct account
{
	bool ischek;
	int accnumber;
	char name[20];
	int balance;
	
	

	void makeaccount(int a, char *n, int b)
	{
	

		cout << "���� ��ȣ : ";
		cin >> accnumber;

		cout << "�� �� : ";
		cin >> name;

		cout << "�� �� : ";
		cin >> balance;

		printaccount();
	}

	void printaccount()
	{
		makeaccount(a, n, b);
			cout << "==================================" << endl;
			cout << "�� �� : " << accnumber << endl;
			cout << "�� �� : " << name << endl;
			cout << "�� �� : " << balance << endl;
			cout << "==================================\n" << endl;
	
	}

	void deleteaccount(int a, char *n, int b)
	{
		a = 0;
		cin >> accnumber;
		n = "--------";
		cin >> name;
		b = 0;
		cin >> balance;

		printaccount();
		
	}

	void deposit(int money)
	{
		
	
		balance = money + balance;
		
	}

	void withdraw(int money)
	{
		if (money <= balance)
		{
			balance = money - balance;
			return;
		}
		else
		{
			cout << "�ܾ��� �����մϴ�." << endl;
			return;
		}

	}
	
	
};

int main()
{
	account bank = { false, 0, "----------", 0 };

	while (true)
	{
		system("cls");
		bank.printaccount();
		cout << "==================================" << endl;
		cout << "[1] ���� ���� [2] ���� ���� [3] �Ա� [4] ���" << endl;
		cout << "==================================" << endl;

		char idx;
		idx = _getch(); //<conio.h> ����*****

		switch (idx)
		{
		case '0':return 0;
		case '1': bank.printaccount(); break;
		case '2': 
		{
			int a;
			char *n;
			int b;
			bank.deleteaccount(a, n, b); break;
		}
		case '3': 
		{
			int money;

			cout << "�Ա� �ݾ� : ";
			cin >> money;

			bank.deposit(money); break;
		}
		case '4':
		{
			int money;

			cout << "��� �ݾ� : ";
			cin >> money;
			bank.withdraw(money); break;
		}

		}

	}
	return 0;

}