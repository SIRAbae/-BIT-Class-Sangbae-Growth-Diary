#include <iostream>
using namespace std;
/*char change(char ch);

int main()
{
	char ch;
	cout << "�Է�(�ҹ���) : ";
	cin >> ch;

	char result = change(ch);

	cout << "��ȯ(�빮��)" << result << endl;
	return 0;

}
char change(char ch)
{
	return ch - ('a' - 'A');
}*/

int number (int num);

int main()
{
	int num1;
	int num2;
	int num3;
	int num4;
	int num5;
	cout << "�Է�1 : ";
	cin >> num1;

	cout << "�Է�2 : ";
	cin >> num2;

	cout << "�Է�3 : ";
	cin >> num3;

	cout << "�Է�4 : ";
	cin >> num4;

	cout << "�Է�5 : ";
	cin >> num5;

	int result = num(ch);

	cout << "���� ��� = " << result << endl;
	return 0;

}
int number(int num)
{
	result = num1 + num2 + num3 + nu + num5;
	return 0;m4
}