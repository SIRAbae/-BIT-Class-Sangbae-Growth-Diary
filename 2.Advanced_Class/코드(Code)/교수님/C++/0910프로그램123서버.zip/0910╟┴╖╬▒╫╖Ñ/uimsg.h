//uimsg.h

void uimsg_GetMessage(HWND hDlg, TCHAR*msg, int size);
void uimsg_ClearEditMsg(HWND hDlg);